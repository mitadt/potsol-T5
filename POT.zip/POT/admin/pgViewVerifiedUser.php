<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PotSol | View Verified Users</title>

    <!-- Bootstrap -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	    <link rel="stylesheet" href="../css/animate.css">
	    <link rel="stylesheet" href="../css/font-awesome.min.css">
	    <link rel="stylesheet" href="../css/jquery.bxslider.css">
	    <link rel="stylesheet" type="text/css" href="../css/normalize.css" />
	    <link rel="stylesheet" type="text/css" href="../css/demo.css" />
	    <link rel="stylesheet" type="text/css" href="../css/set1.css" />
	    <link href="../css/overwrite.css" rel="stylesheet">
	    <link href="../css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
 
    </head>
        <body>
	        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
		    <div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
				    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
					    <span class="sr-only">Toggle navigation</span>
					    <span class="icon-bar"></span>
					    <span class="icon-bar"></span>
					    <span class="icon-bar"></span>
				    </button>
			        <a class="navbar-brand" href="#"><span>PotSol</span></a>
			    </div>
			<div class="navbar-collapse collapse">							
			    <div class="menu">
	                    <ul class="nav nav-tabs" role="tablist">
		                <li role="presentation" class=""><a href="pgHome.php">Home</a></li>
		                <li role="presentation"  class=""><a href="pgViewQueries.php">View Queries</a></li>
		                <li role="presentation"  class=""><a href="pgViewUsers.php">View Users</a></li>
						<li role="presentation"  class=""><a href="pgViewVerifiedUser.php">View Verified Users</a></li>
		                <li role="presentation"  class=""><a href="pgChangePassword.php">ChangePassword</a></li>
		                <li role="presentation"  class=""><a href="pgLogout.php">Logout</a></li>						
	                </ul>
                </div>			
            </div>			
		</div>
	    </nav>
	
	
	<div class="container" >
	<br> <br> <br>
		<div class="row">
			<div class="col-md-12">
			
				<table width="100%" border="1">
					<tr><td>Sr No</td>
                    <td></td>
                    <td>Name</td>
					<td>Month/Year</td>
                    </tr><tr><td>1</td>
                    <th><img src='image4.jpg' width='50px' height='50px' />
                    </th><td>sameen</td><td>01-2019</td></tr>
                    <tr><td>2</td><th><img src='image4.jpg' width='50px' height='50px' />
                    </th><td>hardik</td><td>01-2019</td></tr>
                    <tr><td>3</td><th><img src='image4.jpg' width='50px' height='50px' />
					</th><td>bahvik</td><td>09-2018</td></tr>
                </table>
			</div>
		</div>
	</div>	

		<div class="last-div">
			<div class="container">
				<div class="row">
						
				</div>
			</div>
			<div class="container">
				<center><div class="row">
				
	<ul class="social-network">
		<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook fa-1x"></i></a></li>
		<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter fa-1x"></i></a></li>
		<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin fa-1x"></i></a></li>
		<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest fa-1x"></i></a></li>
		<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus fa-1x"></i></a></li>
	</ul>
				
</div>	</center>			</div>
			
			<a href="" class="scrollup"><i class="fa fa-chevron-up"></i></a>	
				
			
		</div>	
	</footer>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/jquery-2.1.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/wow.min.js"></script>
	<script src="../js/jquery.easing.1.3.js"></script>
	<script src="../js/jquery.isotope.min.js"></script>
	<script src="../js/jquery.bxslider.min.js"></script>
	<script src="../js/jquery-2.1.1.min.js"></script>
	<script src="../jquery.min.js"></script>
	<script src="../jquery.form.js"></script>
	
  </body>
</html>
<?php
define('DB_USER', "USERNAME"); // db user
define('DB_PASSWORD', "PASSWORD"); // db password
define('DB_DATABASE', "DATABASE"); // database name
define('DB_SERVER', "localhost"); // db server
?>
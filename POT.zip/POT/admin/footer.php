<center>
	<div class="row">		
		<ul class="social-network">
			<li><a href="https://www.facebook.com/" data-placement="top" title="Facebook"><i class="fa fa-facebook fa-1x"></i></a></li>
			<li><a href="https://www.twitter.com" data-placement="top" title="Twitter"><i class="fa fa-twitter fa-1x"></i></a></li>
			<li><a href="https://www.linkedin.com" data-placement="top" title="Linkedin"><i class="fa fa-linkedin fa-1x"></i></a></li>
			<li><a href="https://www.pinterest.com" data-placement="top" title="Pinterest"><i class="fa fa-pinterest fa-1x"></i></a></li>
			<li><a href="https://www.google-plus.com" data-placement="top" title="Google plus"><i class="fa fa-google-plus fa-1x"></i></a></li>
		</ul>
	</div>	
</center>
<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "USER"); // db user
define('DB_PASSWORD', "PASSWORD"); // db password
define('DB_DATABASE', "DATABASE"); // database name
define('DB_SERVER', "localhost"); // db server
?>